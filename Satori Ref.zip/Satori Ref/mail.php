<?php
//get data from form  

$email= $_POST['ctc_email'];
$message= $_POST['ctc_message'];
$to = "asaak@satoricreatives.in";
$subject = "Mail From website";
$txt ="Email = " . $email . "\r\n Message =" . $message;
$headers = "From: noreply@yoursite.com" . "\r\n" .
"CC: somebodyelse@example.com";
if($email!=NULL){
    mail($to,$subject,$txt,$headers);
}
//redirect

?>

<script type ="text/JavaScript">';  
echo 'alert(" Your Message was sent successfully ")';  
echo '</script>'; 